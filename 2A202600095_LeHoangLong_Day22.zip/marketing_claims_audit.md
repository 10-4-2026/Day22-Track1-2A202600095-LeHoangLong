# Marketing Claims Audit — PoomsaeAI

**Ngày rà soát:** 8/5/2026
**Người rà soát:** ....

## Bảng claim audit

| # | Câu gốc | Vị trí | Mức | Evidence hiện có | Honest version | Action |
|---|---------|--------|-----|------------------|----------------|--------|
| 1 | """Chấm điểm chuẩn xác 100% như trọng tài quốc tế""" | Landing Page Hero | C | Chưa có kiểm định thực tế từ liên đoàn (VTF) | """Hỗ trợ chấm điểm với độ sai lệch <15% so với trọng tài mẫu""" | Sửa ngay lập tức |
| 2 | """Trên thị trường chưa có sản phẩm tương tự""" | Pitch Memo / Intro | B | Chỉ là nhận định chủ quan, chưa rà soát đối thủ toàn cầu | """Giải pháp tiên phong kết hợp Overlay & Sync tại Việt Nam""" | Sửa trong tuần |
| 3 | """100% vận động viên sẽ tiếp tục sử dụng""" | Pitch Deck (Traction) | B | Số liệu từ survey quy mô nhỏ (n=20), không đại diện | """48% người dùng thử nghiệm phản hồi tích cực và mong muốn đồng hành""" | Cập nhật lại slide |
| 4 | """AI phát hiện mọi lỗi sai nhỏ nhất mắt người không thấy""" | Product Section | C | AI vẫn có xác suất hallucination (ảo giác) | """Hỗ trợ phát hiện các sai lệch góc độ dựa trên Pose Estimation""" | Thêm disclaimer |
| 5 | """LTV/CAC Ratio 380x""" | Financial Summary | B | Con số giả định trên Excel, chưa có dữ liệu thực tế vận hành | """Dự phóng hiệu quả kinh tế đơn vị tiềm năng dựa trên mô hình thử nghiệm""" | Ghi chú ""Dự phóng""" |

## Thống kê
- Tổng số claim: 5
- Mức A: 0 Mức B: 3 Mức C: 2

## TOP 3 priority sửa ngay
1. Claim #1 (Độ chính xác 100%): Đây là lỗi nặng nhất có thể dẫn đến cáo buộc quảng cáo sai sự thật. Cần thay bằng con số sai số kỹ thuật cụ thể từ kết quả test MVP.
2. Claim #4 (Phát hiện mọi lỗi sai): Tránh dùng từ tuyệt đối "mọi", "luôn luôn". Cần bổ sung lớp chặn (Guardrail) và thông báo miễn trừ trách nhiệm chấn thương nếu người dùng tin tưởng tuyệt đối vào AI mà bỏ qua cảm giác cơ thể.
3. Claim #5 (Số liệu tài chính): Phải phân biệt rõ giữa "Dữ liệu thực tế" và "Dự phóng" để tránh gây hiểu lầm cho nhà đầu tư về tình trạng kinh doanh hiện tại.