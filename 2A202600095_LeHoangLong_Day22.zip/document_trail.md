# Document Trail — [Tên startup]
**Date:** [DD/MM/YYYY]

## Bảng đối chiếu 5 loại hồ sơ

| # | Loại | Status | Link/Path | Deadline build |
|---|------|--------|-----------|----------------|
| 1 | Nhật ký kiểm thử claim AI | ✓/✗ | marketing_claims_audit.md | 8/5/2026 |
| 2 | Hồ sơ rà soát điều khoản vendor | ✓/✗ | vendor_terms_review.md | 15/5/2026 |
| 3 | Nhật ký giám sát giao dịch bất thường | ✓/✗ | transaction_monitoring.md | 15/5/2026 |
| 4 | DPIA / CTIA | ✓/✗ | dpia_ctia.md | 15/5/2026 |
| 5 | Phê duyệt nội dung marketing | ✓/✗ | marketing_approval_process.md | 15/5/2026 |

## TOP 1 ưu tiên
**Loại:** [#1 - Nhật ký kiểm thử claim AI]
**Lý do:** Đây là yêu cầu cơ bản nhất và dễ thực hiện nhất, giúp xây dựng lòng tin với nhà đầu tư và khách hàng ngay từ đầu.

## Template build trong 1 tuần
### Người chịu trách nhiệm: (Founder & Tech Lead)
### Tần suất cập nhật: [1 lần / tháng]
### Sample 3-5 dòng:

- Rà soát các trường hợp biên dựa trên phản hồi tiêu cực từ người dùng. Ghi chú lại các trường hợp và đưa ra giải pháp.
- Cập nhật lại nội dung liên quan.
- 