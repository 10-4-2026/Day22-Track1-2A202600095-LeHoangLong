# Territorial Scope — PoomsaeAI
**Date:** 8/5/2026

## Câu hỏi 1: User EU?
- Có user EU hiện tại: 0
- Kế hoạch mở rộng EU 12 tháng: YES(Thị trường EU có phong trào Taekwondo rất mạnh, đặc biệt là Pháp và Đức)
- **Kết luận:** EU AI Act áp dụng = YES (Sẽ áp dụng ngay khi bắt đầu marketing/mở server tại vùng này).

## Câu hỏi 2: Dữ liệu Việt Nam?
### Loại dữ liệu cá nhân đang xử lý:
1. Email (liên hệ nhà tài trợ/đối tác)
### Có chuyển ra nước ngoài: ...
Hiện tại chỉ lưu trữ trong nước, chưa có kế hoạch chuyển ra nước ngoài.
### Kết luận: PDPL áp dụng = YES (gần như chắc chắn) + CTIA = YES
(Dự án phải thực hiện báo cáo Đánh giá tác động xử lý dữ liệu cá nhân - DPIA).
## Câu hỏi 3: Tầng rủi ro Luật AI VN?
- Phân loại: Cao
- Lập luận: Theo Điều 9 Luật AI Việt Nam, các hệ thống AI dùng để đánh giá kết quả học tập, đào tạo hoặc đánh giá năng lực con người (trong thể thao chuyên nghiệp) được xếp vào nhóm rủi ro cao vì kết quả của AI có thể ảnh hưởng đến sự nghiệp và cơ hội của cá nhân.
- Nghĩa vụ tương ứng: 
1. Đăng ký hệ thống AI rủi ro cao với cơ quan quản lý.
2. Thiết lập hồ sơ kỹ thuật và hệ thống quản trị rủi ro (Risk Management System).
3. Đảm bảo tính minh bạch (AI phải giải thích được tại sao trừ điểm).

## 4 deadlines đã note vào Notion
- [x] 1/1/2026 — PDPL hiệu lực (đã qua)
- [x] 1/3/2026 — Luật AI VN hiệu lực (đã qua)
- [ ] 2/8/2026 — EU AI Act high-risk (3 tháng nữa)
- [ ] 1/3/2027 — Hết ân hạn (10 tháng nữa)