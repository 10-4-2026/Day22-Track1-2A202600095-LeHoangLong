I. SƠ ĐỒ LUỒNG DỮ LIỆU (Data Flow)

Video người tập (Dữ liệu sinh trắc học) -> App Mobile -> Server trung gian (VN) -> API Gateway (Japan/US) -> AI Model (Azure/Google) -> Kết quả chấm điểm -> Lưu Database -> Hiển thị cho User.

II. DANH SÁCH VI PHẠM PHÁP LÝ TIỀM NĂNG
VI PHẠM 1: Quảng cáo gian dối về độ chính xác của AI

    Luật áp dụng: Bộ luật Hình sự Việt Nam.

    Điều: Điều 198 (Tội lừa dối khách hàng).

    Bằng chứng trong sản phẩm: "Chấm điểm chuẩn xác 100% như trọng tài quốc tế" (Marketing Materials).

    Pattern khớp với: Vụ kẹo Kera 11/2025. Các KOL bị truy tố vì quảng cáo thực phẩm chức năng có tác dụng như thuốc chữa bệnh. Việc cam kết "100% như trọng tài" khi AI vẫn có sai số là hành vi lừa dối người tiêu dùng.

    Hành động sửa: Thay bằng "Hệ thống hỗ trợ chấm điểm với độ chính xác tương đương >90% trong điều kiện tiêu chuẩn". Bổ sung báo cáo kiểm thử (Testing Report).

    Deadline: Sửa ngay trước khi chạy Ads/Livestream.

VI PHẠM 2: Thổi phồng hiệu quả kinh tế (LTV/CAC) để gọi vốn

    Luật áp dụng: Bộ luật Hình sự Việt Nam.

    Điều: Điều 174 (Tội lừa đảo chiếm đoạt tài sản - nếu dùng số liệu giả để nhận tiền đầu tư).

    Bằng chứng trong sản phẩm: "LTV/CAC Ratio 380.00x... 100% vận động viên sẽ tiếp tục sử dụng" (Pitch Deck).

    Pattern khớp với: Vụ kẹo Kera. Đưa ra các con số thống kê không dựa trên thực tế vận hành mà dựa trên giả định Excel để tạo lòng tin mù quáng.

    Hành động sửa: Ghi chú rõ "Dữ liệu dự phóng (Projection)" hoặc "Kết quả khảo sát trên quy mô hẹp (n=20)".

    Deadline: Trước khi gửi tài liệu cho Angel Investors.

VI PHẠM 3: Khẳng định tính "Duy nhất" thiếu căn cứ

    Luật áp dụng: Luật Cạnh tranh & BLHS.

    Điều: Điều 198 BLHS (Lừa dối khách hàng).

    Bằng chứng trong sản phẩm: "Trên thị trường chưa có sản phẩm tương tự" (Pitch Memo).

    Pattern khớp với: Vụ kẹo Kera. Khẳng định tính độc quyền hoặc duy nhất để hạ thấp đối thủ hoặc đánh lừa người dùng về vị thế sản phẩm.

    Hành động sửa: Sửa thành "Một trong những ứng dụng đầu tiên tích hợp Overlay Sync tại Việt Nam".

    Deadline: 1 tuần.

VI PHẠM 4: Hệ thống AI rủi ro cao không đăng ký

    Luật áp dụng: Luật AI Việt Nam 134/2025.

    Điều: Điều 9 (Phân loại hệ thống AI rủi ro cao).

    Bằng chứng trong sản phẩm: "Chấm điểm tự động... đưa ra kết quả dựa trên luật thi đấu" (PRD). AI tham gia vào việc đánh giá/xếp hạng năng lực con người trong thể thao chuyên nghiệp.

    Pattern khớp với: Pattern kiểm soát EU AI Act. Các hệ thống chấm điểm gây ảnh hưởng đến sự nghiệp cá nhân bị xếp vào nhóm rủi ro cao.

    Hành động sửa: Đăng ký hệ thống với Cổng thông tin AI quốc gia và thiết lập nhật ký kiểm soát lỗi.

    Deadline: 1/3/2026.

VI PHẠM 5: Rủi ro về dòng tiền và thanh toán (Vendor Payment)

    Luật áp dụng: Bộ luật Hình sự.

    Điều: Điều 324 (Tội rửa tiền - liên quan đến cổng thanh toán không phép).

    Bằng chứng trong sản phẩm: "Doanh thu từ Admob... nạp tiền qua các kênh chưa định danh" (Finance Model).

    Pattern khớp với: Vụ Mr Pips 2/2026. Sử dụng các hệ thống thanh toán trung gian không được Ngân hàng Nhà nước cấp phép để luân chuyển dòng tiền từ nước ngoài về.

    Hành động sửa: Chỉ sử dụng các cổng thanh toán có giấy phép tại VN (VNPAY, MoMo, App Store Billing).

    Deadline: Trước khi thu phí người dùng.

III. ƯU TIÊN TOP 5 HÀNH ĐỘNG SỬA TRONG 1 TUẦN

    Sửa nội dung Landing Page & Pitch Deck: Loại bỏ các từ "100%", "duy nhất", "tuyệt đối" để tránh Điều 198 (Vụ Kera).

    Cập nhật UX/UI Flow: Thêm màn hình yêu cầu chấp thuận xử lý dữ liệu sinh trắc học riêng biệt để tuân thủ PDPL Điều 12.

    Thiết lập "AI Human-in-the-loop": Thêm dòng cảnh báo "Kết quả AI chỉ mang tính tham khảo" dưới mọi bảng điểm để giảm tầng rủi ro theo Luật AI VN.

    Xây dựng bản "Điều khoản dịch vụ" (ToS) mới: Quy định rõ trách nhiệm của người dùng và giới hạn trách nhiệm của startup đối với chấn thương thể chất.

    Ký hợp đồng Enterprise với Cloud Vendor: Đảm bảo có điều khoản "Data Processing Agreement" (DPA) xác nhận dữ liệu không bị dùng để train model công cộng.